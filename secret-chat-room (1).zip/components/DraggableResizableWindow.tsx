import React, { useState, useRef, useCallback, ReactNode } from 'react';
import { MoveIcon, CloseIcon } from './icons/Icons';

interface DraggableResizableWindowProps {
  children: ReactNode;
  title: string;
  initialPosition?: { x: number; y: number };
  initialSize?: { width: number; height: number };
  onClose?: () => void;
}

const DraggableResizableWindow: React.FC<DraggableResizableWindowProps> = ({ 
    children, 
    title, 
    initialPosition = { x: 50, y: 50 }, 
    initialSize = { width: 320, height: 180 },
    onClose
}) => {
  const [position, setPosition] = useState(initialPosition);
  const [size, setSize] = useState(initialSize);
  const dragRef = useRef({ x: 0, y: 0 });
  const resizeRef = useRef({ width: 0, height: 0, x: 0, y: 0 });
  const isDragging = useRef(false);
  const isResizing = useRef(false);
  const nodeRef = useRef<HTMLDivElement>(null);

  const handleDragMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    // Prevent dragging when clicking on the close button
    if ((e.target as HTMLElement).closest('button')) {
      return;
    }
    if (nodeRef.current) {
        isDragging.current = true;
        const rect = nodeRef.current.getBoundingClientRect();
        dragRef.current = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
    }
  }, []);
  
  const handleResizeMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    isResizing.current = true;
    resizeRef.current = {
      width: size.width,
      height: size.height,
      x: e.clientX,
      y: e.clientY,
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  }, [size]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging.current) {
      setPosition({
        x: e.clientX - dragRef.current.x,
        y: e.clientY - dragRef.current.y,
      });
    }
    if (isResizing.current) {
      const newWidth = resizeRef.current.width + (e.clientX - resizeRef.current.x);
      const newHeight = resizeRef.current.height + (e.clientY - resizeRef.current.y);
      setSize({
        width: Math.max(200, newWidth), // Min width
        height: Math.max(150, newHeight), // Min height
      });
    }
  }, []);

  const handleMouseUp = useCallback(() => {
    isDragging.current = false;
    isResizing.current = false;
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  }, [handleMouseMove]);

  return (
    <div
      ref={nodeRef}
      className="absolute bg-brand-secondary rounded-lg shadow-2xl border border-slate-600 flex flex-col z-10"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: `${size.width}px`,
        height: `${size.height}px`,
      }}
    >
      <div 
        className="h-8 bg-slate-700 rounded-t-lg flex items-center justify-between px-2 cursor-move"
        onMouseDown={handleDragMouseDown}
      >
        <span className="text-sm font-bold text-brand-light truncate pl-1">{title}</span>
        <div className="flex items-center gap-1">
          <MoveIcon className="w-4 h-4 text-slate-400" />
          {onClose && (
            <button 
                onClick={onClose} 
                className="p-1 rounded-full hover:bg-slate-600"
                title="Close"
            >
                <CloseIcon className="w-4 h-4 text-slate-300"/>
            </button>
          )}
        </div>
      </div>
      <div className="flex-1 relative">
        {children}
        <div 
          className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize"
          onMouseDown={handleResizeMouseDown}
          style={{
             borderBottom: '2px solid #38bdf8',
             borderRight: '2px solid #38bdf8',
          }}
        />
      </div>
    </div>
  );
};

export default DraggableResizableWindow;